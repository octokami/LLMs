def xml_to_dataframe(xml_file, format='jsonl', output_file = 'trial_data', in_dir = in_dir, ACD = False):
    """
    Parse an XML file and convert it to a pandas DataFrame and in the desired format.

    Args:
        xml_url (str): URL of the XML file or local file location
        format: 'jsonl' and 'tsv' accepted
        output_file: name of the file as output
        ACD: Set to True to also parse aspect category

    Returns:
        pandas.DataFrame: DataFrame containing the parsed data.
        file in the desired format in the 'in_dir' with the 'output_file' name
    """
    try:
        with open(xml_file, 'r') as f:
            xml_string = f.read()
    except:
        with urllib.request.urlopen(xml_file) as response:
            xml_string = response.read()

    root = ET.fromstring(xml_string)
    df = pd.DataFrame(columns=['id', 'prompt', 'completion'])

    for Review in root:
        for sentences in Review:
            prompt, completion = list(), list()
            for sentence in sentences:            
                for value in sentence:
                    if value.text != '\n                    ' and value.text != None:
                        prompt.append(value.text)           
                    for opinion in value:
                        if ACD:
                            completion.append(opinion.attrib['target']+'; '+opinion.attrib['category']+'; '+opinion.attrib['polarity'])
                        else:
                            completion.append(opinion.attrib['target']+'; '+opinion.attrib['polarity'])
            # Remove duplicates
            completion = list(dict.fromkeys(completion))
            # Extra formating for clarification for the model
            completion.append(' END') # fixed stop sequence to inform the model when the completion ends
            if len(completion) > 1:
                completion = '\n'.join(completion)
            else:
                completion = ''.join(completion)
            completion = ' '+completion # tokenization starts with a whitespace

            df = pd.concat([df,pd.DataFrame.from_dict({
                'id': Review.attrib['rid'],
                'prompt': (' ').join(prompt)+'\n\n###\n\n', # To separate prompt from completion
                'completion': completion,
                }, orient='index').T])
                            
    df.reset_index(inplace=True, drop=True)

    if format =='jsonl':
        df.drop(columns=['id']).to_json(os.path.join(in_dir, output_file+'.'+format), orient='records', lines=True)
    
    if format == 'tsv':
        df.drop(columns=['id']).to_csv(os.path.join(in_dir, output_file+'.'+format), sep="\t")
        #!openai tools fine_tunes.prepare_data -f os.path.join(in_dir, 'trial_data.tsv')
    
    df.to_parquet(os.path.join(in_dir, output_file+'.parquet'))
    return df